import { applicationDatabaseCommand } from './linux-application-database.js'
import { applicationFileOwnershipGuard } from './linux-php-foundation.js'
import { linuxX86V2ImageProfile } from './linux-image-cpu.js'
import { GHOST_MYSQL_IMAGE, GHOST_MYSQL_BUILDKIT, GHOST_MYSQL_COMPAT_VERSION, ghostMysqlCompatibilityImage, ghostMysqlCompatibilityDockerfile } from './ghost-mysql-compat.js'

const VERSION = '6.57.0'
const COMPOSE_VERSION = '6.56.0'
const PORT = 18110
const GHOST_PORT = 2368
const MARKER = 'WEBMINAI_GHOST_OK'
const SERVICE = 'webminai-ghost-18110'
const APP_ROOT = '/opt/webminai-ghost-18110'
const CLI_ROOT = '/opt/webminai-ghost-cli'
const DATA_ROOT = '/var/lib/webminai-ghost-18110'
const CREDENTIALS = '/root/ghost_credentials'
const SERVICE_ROOT = '/opt/webminai/services/ghost'
const PROJECT = 'webminai-ghost-18110'
const DATABASE = 'webminai_ghost_18110'
const DATABASE_USER = 'webminai_ghost'
const GHOST_IMAGE = 'ghost@sha256:5cb081c6be54af505f28cde86f209e8e43910da0a406226a9e5e98045388599b'
const MYSQL_IMAGE = GHOST_MYSQL_IMAGE
const NGINX_IMAGE = 'nginx@sha256:97d490c12ba55b4946b01546d1c3ed324e8d41ab1c9fcb2a616aa470620e5b46'
const IMAGES = [GHOST_IMAGE, MYSQL_IMAGE, NGINX_IMAGE]
const DPKG_PACKAGE_FORMAT = '$' + '{db:Status-Abbrev} $' + '{binary:Package} $' + '{Version}\\n'
const DOCKER_CODENAME_FALLBACK = '$' + '{UBUNTU_CODENAME:-$VERSION_CODENAME}'
const MYSQL_PASSWORD_REFERENCE = '$$' + '{MYSQL_PASSWORD}'

export function buildGhostTask (taskId, linuxContext, docker = {}) {
  if (!Number.isInteger(taskId) || taskId < 1) throw new TypeError('task id must be a positive integer')
  if (!linuxContext?.identity || !linuxContext?.management) throw new TypeError('Ghost task requires a Linux host context')
  if (docker.preferred === true) return buildComposeTask(taskId, linuxContext, docker)
  if (linuxContext.identity.id === 'ubuntu' && ['22.04', '24.04'].includes(linuxContext.identity.versionId)) {
    return buildUbuntuTask(taskId, linuxContext)
  }
  return buildCompatibilityTask(taskId, linuxContext)
}

export function ghostRelease () {
  return Object.freeze({ version: VERSION, composeVersion: COMPOSE_VERSION, images: Object.freeze([...IMAGES]) })
}

function buildCompatibilityTask (taskId, context) {
  const state = `/var/lib/webminai/task-state/${taskId}-ghost-compatibility`
  const identity = context.identity
  const report = join([
    'set -eu', `test ! -e ${quote(APP_ROOT)}`, `test ! -e ${quote(DATA_ROOT)}`, `test ! -e ${quote(CREDENTIALS)}`,
    `install -d -o root -g root -m 0700 ${quote(state)}`,
    `printf '%s\\n' ${quote(`Ghost ${VERSION} production is unsupported on ${identity.id} ${identity.versionId ?? ''} without an approved container route; Node.js 22 and Oracle MySQL 8 are required, and MariaDB or production SQLite substitutions are forbidden.`)} > ${quote(`${state}/report.txt`)}`,
    `chmod 0600 ${quote(`${state}/report.txt`)}`, `printf '%s\\n' ${quote(state)}`
  ])
  const cleanup = `set -eu; rm -rf -- ${quote(state)}; printf '%s\\n' compatibility-report-removed`
  return envelope({
    context,
    route: 'no-change-incompatible',
    overview: `Record a no-change Ghost production compatibility result for ${identity.id} ${identity.versionId ?? ''}.`,
    files: [state, `${state}/report.txt`],
    commands: [item('record-compatibility', 'preflight', report, 'Record the reviewed no-change compatibility result without installing an unsupported database stack')],
    revertCommands: [item('remove-compatibility-report', 'cleanup', cleanup, 'Remove only the task-owned compatibility report', [], 30000, undefined, 'destructive')],
    verifyApplied: `test -s ${quote(`${state}/report.txt`)} && grep -Fq 'Oracle MySQL 8' ${quote(`${state}/report.txt`)} && test ! -e ${quote(APP_ROOT)} && test ! -e ${quote(CREDENTIALS)}`,
    verifyReverted: `test ! -e ${quote(state)}`
  })
}

function buildUbuntuTask (taskId, context) {
  const state = `/var/lib/webminai/task-state/${taskId}-ghost-linux`
  const paths = ubuntuPaths()
  const commands = [
    item('capture-baseline', 'baseline', ubuntuBaseline(state, paths), 'Capture package, repository, nginx, MySQL, and task-owned path state exactly once'),
    item('install-stack', 'packages', ubuntuPackages(state), 'Install private Node.js 22, Oracle MySQL 8, nginx, and required utilities', ['capture-baseline'], 1200000, 'job'),
    item('generate-credentials', 'secrets', credentialsCommand(), 'Generate the database password on-host without emitting it', ['capture-baseline']),
    item('initialize-database', 'database', ubuntuDatabase(state), 'Create the isolated MySQL database and least-privilege Ghost account', ['install-stack', 'generate-credentials'], 900000, 'job'),
    item('install-ghost', 'acquire', ubuntuGhostInstall(state), `Install Ghost ${VERSION} through the pinned official Ghost-CLI`, ['install-stack'], 3600000, 'job'),
    item('configure-ghost', 'configure', ubuntuConfigure(paths), 'Create the locked service, protected environment, and nginx reverse proxy', ['initialize-database', 'install-ghost']),
    item('verify-ghost', 'verify', ubuntuVerify(), 'Verify Ghost, MySQL persistence, nginx marker, and restart recovery', ['configure-ghost'], 1200000, 'job')
  ]
  const revertCommands = [
    item('stop-ghost', 'cleanup', ubuntuStop(state, paths), 'Stop and remove only the task-owned Ghost service and nginx site', [], 300000, undefined, 'destructive'),
    item('drop-database', 'cleanup', ubuntuDropDatabase(state), 'Drop only the task-owned MySQL database and account', ['stop-ghost'], 300000, undefined, 'destructive'),
    item('remove-ghost-files', 'cleanup', `set -eu; ${applicationFileOwnershipGuard(state, ubuntuOwnedPaths(paths))}; rm -rf -- ${quote(APP_ROOT)} ${quote(CLI_ROOT)} ${quote(DATA_ROOT)} ${quote(CREDENTIALS)}`, 'Remove task-owned application, CLI, content, and protected credentials', ['drop-database'], 300000, undefined, 'destructive'),
    item('restore-stack', 'cleanup', ubuntuRestore(state, paths), 'Restore package, repository, nginx, and MySQL service state from the baseline', ['remove-ghost-files'], 1200000, 'job', 'destructive')
  ]
  return envelope({
    context,
    route: 'native-ubuntu-mysql8',
    overview: `Deploy Ghost ${VERSION} with Node.js 22, MySQL 8, systemd, and nginx on port ${PORT}.`,
    files: [state, APP_ROOT, CLI_ROOT, DATA_ROOT, CREDENTIALS, ...Object.values(paths)],
    commands,
    revertCommands,
    verifyApplied: ubuntuVerify(),
    verifyReverted: `test ! -e ${quote(APP_ROOT)} && test ! -e ${quote(CLI_ROOT)} && test ! -e ${quote(DATA_ROOT)} && test ! -e ${quote(CREDENTIALS)} && test ! -e ${quote(state)} && test ! -e ${quote(paths.serviceFile)} && test ! -e ${quote(paths.nginxVhost)}`
  })
}

function buildComposeTask (taskId, context, docker) {
  if (!docker.ready && docker.installMethod !== 'official-apt') throw new Error('learned Ghost Compose setup requires Docker ready or the reviewed official apt route')
  const state = `/var/lib/webminai/task-state/${taskId}-ghost-compose`
  const profileProbe = docker.platform === 'macos' ? 'printf standard' : linuxX86V2ImageProfile()
  const commands = [
    item('capture-baseline', 'baseline', composeBaseline(state, taskId, profileProbe), 'Detect CPU image compatibility and capture Docker, image, service, and task-path state exactly once'),
    item('prepare-docker', 'packages', prepareDocker(state), 'Install Docker and Compose only when the reviewed host route requires them', ['capture-baseline'], 900000, 'job'),
    item('generate-credentials', 'secrets', credentialsCommand(), 'Generate MySQL credentials on-host without emitting them', ['capture-baseline']),
    item('write-compose', 'configure', writeCompose(state, taskId, profileProbe), 'Write the reviewed Ghost project: standard maintained MySQL image, or checksum-pinned Debian MySQL build only for a CPU lacking x86-64-v2', ['prepare-docker', 'generate-credentials']),
    item('acquire-images', 'acquire', acquireComposeImages(state, taskId, profileProbe), 'Acquire pinned images and build the maintained MySQL alternative only when CPU evidence requires it', ['write-compose'], 3600000, 'job'),
    item('start-compose', 'services', startCompose(), 'Start the reviewed Ghost and MySQL services without pulling or building images', ['acquire-images'], 900000, 'job'),
    item('verify-compose', 'verify', verifyCompose(state), 'Verify Ghost version, selected MySQL version, persistence, marker access, and application health', ['start-compose'], 1200000, 'job')
  ]
  const revertCommands = [
    item('remove-compose-project', 'cleanup', removeCompose(state, taskId), 'Remove only the task-owned containers, builder, volumes, network, and unchanged newly acquired images', [], 1200000, 'job', 'destructive'),
    item('remove-compose-files', 'cleanup', `set -eu; rm -rf -- ${quote(SERVICE_ROOT)} ${quote(CREDENTIALS)}`, 'Remove task-owned Compose files and protected credentials', ['remove-compose-project'], 300000, undefined, 'destructive'),
    item('restore-docker', 'cleanup', restoreDocker(state), 'Restore Docker package and service state when Docker was introduced by this task', ['remove-compose-files'], 900000, 'job', 'destructive')
  ]
  return envelope({
    context,
    route: 'compose-mysql8',
    overview: `Deploy official Ghost ${COMPOSE_VERSION}, maintained MySQL 8.4 and nginx on port ${PORT}. CPUs supporting x86-64-v2 use the standard pinned image; older x86 CPUs build a pinned Debian/MySQL ${GHOST_MYSQL_COMPAT_VERSION} alternative. Existing Ghost resources are never adopted or downgraded.`,
    files: [state, SERVICE_ROOT, `${SERVICE_ROOT}/compose.yaml`, `${SERVICE_ROOT}/nginx.conf`, `${SERVICE_ROOT}/mysql-compat/Dockerfile`, CREDENTIALS],
    commands,
    revertCommands,
    verifyApplied: verifyCompose(state),
    verifyReverted: `test ! -e ${quote(SERVICE_ROOT)} && test ! -e ${quote(CREDENTIALS)} && test ! -e ${quote(state)} && { ! command -v docker >/dev/null 2>&1 || ! docker ps -aq --filter label=com.docker.compose.project=${quote(PROJECT)} | grep -q .; }`
  })
}

function envelope ({ context, route, overview, files, commands, revertCommands, verifyApplied, verifyReverted }) {
  const identity = context.identity
  return {
    plan: {
      summary: route === 'no-change-incompatible' ? 'Record Ghost production compatibility result' : `Deploy a learned reversible ${route.startsWith('compose') ? 'Ghost Compose' : 'native Ghost'} service`,
      changeOverview: overview,
      modifiedFiles: files,
      assumptions: [
        `Authoritative Linux profile: ${identity.id} ${identity.versionId ?? ''}`.trim(),
        `Resolved Ghost matrix: native ${VERSION} or official Compose ${COMPOSE_VERSION}, Node.js 22, and Oracle MySQL 8.`,
        'Database credentials are generated on-host and only protected paths are included in plans and logs.'
      ],
      warnings: route === 'no-change-incompatible'
        ? ['No application is installed because this host lacks an approved Ghost production route; MariaDB and production SQLite substitutions are forbidden.']
        : [`This controlled validation publishes TCP port ${PORT} through nginx and does not configure public DNS or TLS.`],
      requiresConfirmation: true,
      compatibilityManifest: compatibilityManifest(context, route),
      commands,
      revertCommands
    },
    verifyApplied,
    verifyReverted,
    stateProbe: `for path in ${files.map(quote).join(' ')}; do if [ -e "$path" ]; then printf 'present=%s\\n' "$path"; else printf 'absent=%s\\n' "$path"; fi; done`
  }
}

function compatibilityManifest (context, route) {
  return {
    format: 'webminai-compatibility-manifest',
    version: 1,
    application: { id: 'ghost', version: route.startsWith('compose') ? COMPOSE_VERSION : VERSION },
    host: { fingerprint: context.fingerprint, distribution: context.identity.id, distributionVersion: context.identity.versionId, architecture: context.identity.architecture, family: context.management.family },
    selectedRoute: { id: route, status: route === 'no-change-incompatible' ? 'unsupported' : 'supported' },
    components: [
      { profileId: 'nodejs', selectedVersion: route.startsWith('compose') ? 'image-managed' : '22.23.1', source: route.startsWith('compose') ? 'official-container-image' : 'checksum-pinned-official-node-archive', status: route === 'no-change-incompatible' ? 'unavailable' : 'supported' },
      { profileId: 'mysql', selectedVersion: route.startsWith('compose') ? '8.4 (hardware-selected image)' : '8', source: route.startsWith('compose') ? 'official-image-or-checksum-pinned-vendor-packages' : 'ubuntu-package', status: route === 'no-change-incompatible' ? 'unavailable' : 'supported' },
      { profileId: 'nginx', selectedVersion: 'distribution-or-image', source: 'reviewed-profile', status: route === 'no-change-incompatible' ? 'not-selected' : 'supported' }
    ]
  }
}

function ubuntuPaths () {
  return {
    serviceFile: `/etc/systemd/system/${SERVICE}.service`,
    nginxVhost: `/etc/nginx/sites-available/${SERVICE}.conf`,
    nginxEnableLink: `/etc/nginx/sites-enabled/${SERVICE}.conf`,
    nodeKey: '/usr/share/keyrings/nodesource.gpg',
    nodeSource: '/etc/apt/sources.list.d/nodesource.sources',
    nodePreference: '/etc/apt/preferences.d/nodejs',
    nsolidPreference: '/etc/apt/preferences.d/nsolid'
  }
}

function ubuntuOwnedPaths (paths) {
  return [APP_ROOT, CLI_ROOT, DATA_ROOT, CREDENTIALS, paths.serviceFile, paths.nginxVhost, paths.nginxEnableLink]
}

function ubuntuBaseline (state, paths) {
  const owned = ubuntuOwnedPaths(paths)
  const preserved = [paths.nodeKey, paths.nodeSource, paths.nodePreference, paths.nsolidPreference]
  return join([
    'set -eu', `test ! -L ${quote(state)}`, `if [ ! -s ${quote(`${state}/packages.before`)} ]; then`, ...owned.map(path => `if [ -e ${quote(path)} ] || [ -L ${quote(path)} ]; then printf '%s\\n' ${quote(`BASELINE_DRIFT: managed path already exists: ${path}`)} >&2; exit 1; fi`),
    `install -d -o root -g root -m 0700 ${quote(`${state}/backup`)}`,
    `if [ ! -e /var/lib/mysql ] && [ ! -L /var/lib/mysql ]; then : > ${quote(`${state}/mysql-data.absent`)}; fi`,
    `dpkg-query -W -f=${quote(DPKG_PACKAGE_FORMAT)} | LC_ALL=C sort -u > ${quote(`${state}/packages.before`)}`,
    `systemctl is-active --quiet nginx 2>/dev/null && : > ${quote(`${state}/nginx.active`)} || true`,
    `systemctl is-enabled --quiet nginx 2>/dev/null && : > ${quote(`${state}/nginx.enabled`)} || true`,
    `systemctl is-active --quiet mysql 2>/dev/null && : > ${quote(`${state}/mysql.active`)} || true`,
    `systemctl is-enabled --quiet mysql 2>/dev/null && : > ${quote(`${state}/mysql.enabled`)} || true`,
    ...preserved.map((path, index) => `if [ -e ${quote(path)} ]; then cp -a -- ${quote(path)} ${quote(`${state}/backup/${index}`)}; : > ${quote(`${state}/backup-${index}.existed`)}; fi`),
    'fi', 'printf \'%s\\n\' baseline-ready'
  ])
}

function ubuntuPackages (state) {
  return join([
    'set -eu', 'umask 077',
    'if [ -e /var/lib/mysql/aria_log_control ] || { [ -s /var/lib/mysql/mysql_upgrade_info ] && grep -qi MariaDB /var/lib/mysql/mysql_upgrade_info; }; then printf \'%s\\n\' \'Existing MariaDB data requires an operator-reviewed migration before MySQL installation\' >&2; exit 1; fi',
    'export DEBIAN_FRONTEND=noninteractive',
    `status=0; ( apt-get update && apt-get -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold -o Dpkg::Options::=--force-confmiss install -y ca-certificates curl gnupg nginx mysql-server openssl ) > ${quote(`${state}/packages.log`)} 2>&1 || status=$?`,
    `if [ "$status" -ne 0 ]; then tail -c 4000 ${quote(`${state}/packages.log`)} || true; exit "$status"; fi`,
    `if [ ! -x ${quote(`${CLI_ROOT}/bin/node`)} ]; then`,
    "case $(uname -m) in x86_64) arch=x64; checksum=7a8cb04b4a1df4eaf432125324b81b29a088e73570a23259a8de1c65d07fc129;; aarch64|arm64) arch=arm64; checksum=543fa39e57d4c07855939459a323f4deb9a79dd1bb45e6e99458b0f2de10db8d;; *) printf '%s\\n' 'Unsupported Ghost Node runtime architecture' >&2; exit 1;; esac",
    `archive=${quote(`${state}/node-runtime.tar.gz`)}`,
    'curl --fail --location --silent --show-error --connect-timeout 15 --max-time 600 "https://nodejs.org/dist/v22.23.1/node-v22.23.1-linux-$arch.tar.gz" --output "$archive"',
    'printf \'%s  %s\\n\' "$checksum" "$archive" | sha256sum -c -',
    `install -d -o root -g root -m 0755 ${quote(CLI_ROOT)}`,
    `tar -xzf "$archive" --strip-components=1 -C ${quote(CLI_ROOT)}`, 'rm -- "$archive"', 'fi',
    `export PATH=${quote(`${CLI_ROOT}/bin`)}:"$PATH"`,
    'node -e "process.exit(process.versions.node===\'22.23.1\'?0:1)"',
    'npm --version >/dev/null', 'mysqld --version | grep -Eq \'Ver 8\\.0\' || { printf \'Ghost production requires Oracle MySQL 8.0\\n\' >&2; exit 1; }',
    'systemctl enable --now mysql', 'systemctl enable --now nginx',
    `dpkg-query -W -f=${quote(DPKG_PACKAGE_FORMAT)} | LC_ALL=C sort -u > ${quote(`${state}/packages.after`)}`,
    addedDebianPackages(state),
    'printf \'%s\\n\' stack-ready'
  ])
}

function credentialsCommand () {
  return join([
    'set -eu', 'umask 077', `install -d -o root -g root -m 0700 ${quote(CREDENTIALS)}`,
    `[ -s ${quote(`${CREDENTIALS}/database_password`)} ] || openssl rand -hex 32 > ${quote(`${CREDENTIALS}/database_password`)}`,
    `[ -s ${quote(`${CREDENTIALS}/database_root_password`)} ] || openssl rand -hex 32 > ${quote(`${CREDENTIALS}/database_root_password`)}`,
    `chmod 0600 ${quote(`${CREDENTIALS}/database_password`)} ${quote(`${CREDENTIALS}/database_root_password`)}`,
    `printf '%s\\n' ${quote(CREDENTIALS)}`
  ])
}

function ubuntuDatabase (state) {
  return join([
    'set -eu', 'ready=', 'for attempt in $(seq 1 60); do mysqladmin ping --silent >/dev/null 2>&1 && ready=yes && break; sleep 2; done', '[ "$ready" = yes ]',
    `password=$(sed -n 1p ${quote(`${CREDENTIALS}/database_password`)})`,
    applicationDatabaseCommand({ state, database: DATABASE, user: DATABASE_USER, host: '127.0.0.1', credentials: CREDENTIALS, client: 'mysql', passwordFile: 'database_password', collation: 'utf8mb4_0900_ai_ci' }),
    `MYSQL_PWD="$password" mysql --protocol=TCP -h 127.0.0.1 -u ${DATABASE_USER} ${DATABASE} -e 'SELECT 1' >/dev/null`, 'printf \'%s\\n\' database-ready'
  ])
}

function ubuntuGhostInstall (state) {
  return join([
    'set -eu', 'umask 022', `if ! id webminai-ghost >/dev/null 2>&1; then useradd -r -d ${quote(DATA_ROOT)} -s /usr/sbin/nologin webminai-ghost; : > ${quote(`${state}/user-created`)}; fi`,
    `export PATH=${quote(`${CLI_ROOT}/bin`)}:"$PATH"`,
    'export NODE_OPTIONS="${NODE_OPTIONS:-} --network-family-autoselection-attempt-timeout=5000"', // eslint-disable-line no-template-curly-in-string
    `install -d -o webminai-ghost -g webminai-ghost -m 0750 ${quote(DATA_ROOT)}`, `install -d -o webminai-ghost -g webminai-ghost -m 0755 ${quote(APP_ROOT)}`, `install -d -o root -g root -m 0700 ${quote(`${state}/npm-cache`)}`, `install -d -o webminai-ghost -g webminai-ghost -m 0700 ${quote(`${DATA_ROOT}/npm-cache`)}`,
    `if [ ! -x ${quote(`${CLI_ROOT}/bin/ghost`)} ]; then npm_config_cache=${quote(`${state}/npm-cache`)} npm install --global --prefix ${quote(CLI_ROOT)} --omit=dev --no-audit --no-fund --loglevel=error ghost-cli@1.29.1; fi`,
    `if [ ! -x ${quote(`${CLI_ROOT}/bin/pnpm`)} ]; then npm_config_cache=${quote(`${state}/npm-cache`)} npm install --global --prefix ${quote(CLI_ROOT)} --omit=dev --no-audit --no-fund --loglevel=error pnpm@11.15.1; fi`,
    `if [ ! -f ${quote(`${APP_ROOT}/current/package.json`)} ]; then chown webminai-ghost:webminai-ghost ${quote(APP_ROOT)}; runuser -u webminai-ghost -- env HOME=${quote(DATA_ROOT)} PATH=${quote(`${CLI_ROOT}/bin:/usr/bin:/bin`)} npm_config_cache=${quote(`${DATA_ROOT}/npm-cache`)} ${quote(`${CLI_ROOT}/bin/ghost`)} install ${quote(VERSION)} --dir ${quote(APP_ROOT)} --no-prompt --no-setup --no-start --no-stack --no-color; fi`,
    `node -p "require('${APP_ROOT}/current/package.json').version" | grep -Fx ${quote(VERSION)}`, 'printf \'%s\\n\' ghost-installed'
  ])
}

function ubuntuConfigure (paths) {
  const config = JSON.stringify({ url: `http://__PRIMARY__:${PORT}/blog/`, server: { host: '127.0.0.1', port: GHOST_PORT }, database: { client: 'mysql', connection: { host: '127.0.0.1', port: 3306, user: DATABASE_USER, database: DATABASE } }, paths: { contentPath: `${DATA_ROOT}/content` }, privacy: { useUpdateCheck: false } }, null, 2)
  const unit = ['[Unit]', 'Description=Intent AI Ops Ghost validation service', 'After=network-online.target mysql.service', 'Wants=network-online.target', 'Requires=mysql.service', '', '[Service]', 'Type=simple', 'User=webminai-ghost', 'Group=webminai-ghost', `WorkingDirectory=${APP_ROOT}`, 'Environment=NODE_ENV=production', `EnvironmentFile=${CREDENTIALS}/service.env`, `ExecStart=${CLI_ROOT}/bin/node ${APP_ROOT}/current/index.js`, 'Restart=on-failure', 'RestartSec=5', 'NoNewPrivileges=true', 'PrivateTmp=true', '', '[Install]', 'WantedBy=multi-user.target'].join('\n')
  const nginx = ['server {', `    listen ${PORT};`, '    server_name _;', '    location = / { default_type text/plain; return 200 "' + MARKER + '\\n"; }', '    location /blog/ {', `        proxy_pass http://127.0.0.1:${GHOST_PORT};`, '        proxy_set_header Host $host;', '        proxy_set_header X-Real-IP $remote_addr;', '        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;', '        proxy_set_header X-Forwarded-Proto $scheme;', '    }', '}'].join('\n')
  return join([
    'set -eu', `id webminai-ghost >/dev/null 2>&1 || useradd -r -d ${quote(DATA_ROOT)} -s /usr/sbin/nologin webminai-ghost`,
    `install -d -o webminai-ghost -g webminai-ghost -m 0750 ${quote(DATA_ROOT)} ${quote(`${DATA_ROOT}/content`)}`,
    `if [ ! -d ${quote(`${DATA_ROOT}/content/themes/source`)} ]; then cp -a ${quote(`${APP_ROOT}/content/`)}. ${quote(`${DATA_ROOT}/content/`)}; fi`, `chown -R webminai-ghost:webminai-ghost ${quote(`${DATA_ROOT}/content`)}`,
    `password=$(sed -n 1p ${quote(`${CREDENTIALS}/database_password`)})`, `chgrp webminai-ghost ${quote(CREDENTIALS)}`, `chmod 0710 ${quote(CREDENTIALS)}`,
    `umask 077; printf 'database__connection__password=%s\\n' "$password" > ${quote(`${CREDENTIALS}/service.env`)}`, `chown root:webminai-ghost ${quote(`${CREDENTIALS}/service.env`)}`, `chmod 0640 ${quote(`${CREDENTIALS}/service.env`)}`,
    "primary=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for (field=1; field<=NF; field++) if ($field == \"src\") { print $(field+1); exit }}' || true)", "[ -n \"$primary\" ] || primary=$(hostname -I 2>/dev/null | awk '{print $1}')", "case \"$primary\" in ''|*[!0-9a-fA-F:.]*) printf 'could not resolve a safe primary address\\n' >&2; exit 1;; esac",
    `printf '%s\\n' ${config.split('\n').map(quote).join(' ')} | sed "s/__PRIMARY__/$primary/" > ${quote(`${APP_ROOT}/config.production.json`)}`, `chown webminai-ghost:webminai-ghost ${quote(`${APP_ROOT}/config.production.json`)}`, `chmod 0640 ${quote(`${APP_ROOT}/config.production.json`)}`,
    `printf '%s\\n' ${unit.split('\n').map(quote).join(' ')} > ${quote(paths.serviceFile)}`, `chmod 0644 ${quote(paths.serviceFile)}`,
    `printf '%s\\n' ${nginx.split('\n').map(quote).join(' ')} > ${quote(paths.nginxVhost)}`, `chmod 0644 ${quote(paths.nginxVhost)}`, `ln -sfn ${quote(paths.nginxVhost)} ${quote(paths.nginxEnableLink)}`,
    'systemctl daemon-reload', `systemctl enable --now ${quote(SERVICE)}`, 'nginx -t', 'systemctl reload nginx', 'printf \'%s\\n\' configured'
  ])
}

function ubuntuVerify () {
  return join([
    'set -eu', waitUrl(`http://127.0.0.1:${GHOST_PORT}/blog/`, 180),
    `test -d ${quote(`${DATA_ROOT}/content`)}`, `password=$(sed -n 1p ${quote(`${CREDENTIALS}/database_password`)})`,
    `MYSQL_PWD="$password" mysql --protocol=TCP -h 127.0.0.1 -u ${DATABASE_USER} ${DATABASE} --batch --skip-column-names -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='${DATABASE}'" | awk '$1 > 0 { ok=1 } END { exit !ok }'`,
    `curl --fail --silent --show-error --max-time 5 http://127.0.0.1:${PORT}/ | grep -Fx ${quote(MARKER)}`,
    `curl --fail --silent --show-error --max-time 10 http://127.0.0.1:${PORT}/blog/ >/dev/null`,
    `systemctl restart ${quote(SERVICE)}`, waitUrl(`http://127.0.0.1:${GHOST_PORT}/blog/`, 180), 'printf \'%s\\n\' ghost-verified'
  ])
}

function ubuntuStop (state, paths) {
  return join([
    'set -eu', applicationFileOwnershipGuard(state, ubuntuOwnedPaths(paths)), `systemctl disable --now ${quote(SERVICE)} 2>/dev/null || true`, `rm -f -- ${quote(paths.serviceFile)}`, 'systemctl daemon-reload',
    `rm -f -- ${quote(paths.nginxEnableLink)} ${quote(paths.nginxVhost)}`, 'if command -v nginx >/dev/null 2>&1; then nginx -t', 'systemctl is-active --quiet nginx && systemctl reload nginx || true', 'fi'
  ])
}

function ubuntuDropDatabase (state) {
  return applicationDatabaseCommand({ state, database: DATABASE, user: DATABASE_USER, host: '127.0.0.1', client: 'mysql', rollback: true })
}

function ubuntuRestore (state, paths) {
  const preserved = [paths.nodeKey, paths.nodeSource, paths.nodePreference, paths.nsolidPreference]
  const commands = ['set -eu', `test ! -L ${quote(state)}`, `[ -d ${quote(state)} ] || { printf '%s\n' already-reverted; exit 0; }`]
  preserved.forEach((path, index) => commands.push(`if [ -e ${quote(`${state}/backup-${index}.existed`)} ]; then rm -rf -- ${quote(path)}; cp -a -- ${quote(`${state}/backup/${index}`)} ${quote(path)}; else rm -rf -- ${quote(path)}; fi`))
  commands.push(removeDebianPackages(`${state}/packages.added`))
  commands.push(`if systemctl cat nginx >/dev/null 2>&1; then if [ -e ${quote(`${state}/nginx.enabled`)} ]; then systemctl enable nginx >/dev/null 2>&1 || true; else systemctl disable nginx >/dev/null 2>&1 || true; fi; if [ -e ${quote(`${state}/nginx.active`)} ]; then systemctl start nginx; else systemctl stop nginx 2>/dev/null || true; fi; fi`)
  commands.push(`if systemctl cat mysql >/dev/null 2>&1; then if [ -e ${quote(`${state}/mysql.enabled`)} ]; then systemctl enable mysql >/dev/null 2>&1 || true; else systemctl disable mysql >/dev/null 2>&1 || true; fi; if [ -e ${quote(`${state}/mysql.active`)} ]; then systemctl start mysql; else systemctl stop mysql 2>/dev/null || true; fi; fi`)
  commands.push(`if [ -e ${quote(`${state}/mysql-data.absent`)} ] && { [ -e /var/lib/mysql ] || [ -L /var/lib/mysql ]; }; then printf '%s\\n' 'DATABASE_DATA_REMAINS: MySQL created data outside the baseline. Preserve it and review a separate cleanup before continuing rollback.' >&2; exit 1; fi`)
  commands.push(`if [ -e ${quote(`${state}/user-created`)} ]; then id webminai-ghost >/dev/null 2>&1 && userdel webminai-ghost 2>/dev/null || true; fi`, `rm -rf -- ${quote(state)}`)
  return join(commands)
}

function composeImages (taskId) { return [...IMAGES, ghostMysqlCompatibilityImage(taskId), GHOST_MYSQL_BUILDKIT] }

function composeBaseline (state, taskId, profileProbe) {
  return join([
    'set -eu', `image_cpu_profile=$(${profileProbe})`, `if [ ! -s ${quote(`${state}/packages.before`)} ]; then`, `test ! -e ${quote(SERVICE_ROOT)}`, `test ! -e ${quote(CREDENTIALS)}`,
    `if command -v docker >/dev/null 2>&1; then test -z "$(docker ps -aq --filter label=com.docker.compose.project=${quote(PROJECT)})"; test -z "$(docker volume ls -q --filter label=com.docker.compose.project=${quote(PROJECT)})"; test -z "$(docker network ls -q --filter label=com.docker.compose.project=${quote(PROJECT)})"; if [ "$image_cpu_profile" = compat ]; then ! docker image inspect ${quote(ghostMysqlCompatibilityImage(taskId))} >/dev/null 2>&1; fi; fi`,
    `install -d -o root -g root -m 0700 ${quote(state)}`, `dpkg-query -W -f=${quote(DPKG_PACKAGE_FORMAT)} | LC_ALL=C sort -u > ${quote(`${state}/packages.before`)}`,
    `printf '%s\\n' "$image_cpu_profile" > ${quote(`${state}/image-profile`)}`,
    `systemctl is-active --quiet docker 2>/dev/null && : > ${quote(`${state}/docker.active`)} || true`, `command -v docker >/dev/null 2>&1 && : > ${quote(`${state}/docker.existed`)} || true`,
    ...composeImages(taskId).map((image, index) => `docker image inspect ${quote(image)} >/dev/null 2>&1 && : > ${quote(`${state}/image-${index}.existed`)} || true`),
    'fi', 'printf \'%s\\n\' baseline-ready'
  ])
}

function prepareDocker (state) {
  return join([
    'set -eu', 'if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then :; else',
    `[ ! -e ${quote(`${state}/docker.existed`)} ]`, 'export DEBIAN_FRONTEND=noninteractive', 'apt-get update', 'apt-get install -y ca-certificates curl',
    'install -d -m 0755 /etc/apt/keyrings', 'curl --fail --location --silent --show-error https://download.docker.com/linux/ubuntu/gpg --output /etc/apt/keyrings/docker.asc', 'chmod 0644 /etc/apt/keyrings/docker.asc',
    '. /etc/os-release', `arch=$(dpkg --print-architecture); codename=${DOCKER_CODENAME_FALLBACK}`,
    'printf \'%s\\n\' \'Types: deb\' \'URIs: https://download.docker.com/linux/ubuntu\' "Suites: $codename" \'Components: stable\' "Architectures: $arch" \'Signed-By: /etc/apt/keyrings/docker.asc\' > /etc/apt/sources.list.d/docker.sources',
    'apt-get update', 'apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin', 'systemctl start docker', 'fi',
    'docker info >/dev/null', 'docker compose version >/dev/null', `dpkg-query -W -f=${quote(DPKG_PACKAGE_FORMAT)} | LC_ALL=C sort -u > ${quote(`${state}/packages.after`)}`,
    addedDebianPackages(state)
  ])
}

function writeCompose (state, taskId, profileProbe) {
  const compose = [
    'services:', '  db:', `    image: ${MYSQL_IMAGE}`, '    restart: unless-stopped', `    env_file: ${CREDENTIALS}/credentials.env`, '    environment:', `      MYSQL_DATABASE: ${DATABASE}`, `      MYSQL_USER: ${DATABASE_USER}`, '    volumes:', '      - mysql_data:/var/lib/mysql', '    healthcheck:', `      test: ${JSON.stringify(['CMD-SHELL', `MYSQL_PWD="${MYSQL_PASSWORD_REFERENCE}" mysql --protocol=TCP -h 127.0.0.1 --user=${DATABASE_USER} --database=${DATABASE} --batch --skip-column-names --execute="SELECT 1" >/dev/null`])}`, '      interval: 5s', '      timeout: 5s', '      retries: 120', '      start_period: 30s',
    '  ghost:', `    image: ${GHOST_IMAGE}`, '    restart: unless-stopped', `    env_file: ${CREDENTIALS}/credentials.env`, '    environment:', '      NODE_ENV: production', '      database__client: mysql', '      database__connection__host: db', `      database__connection__user: ${DATABASE_USER}`, `      database__connection__database: ${DATABASE}`, '    volumes:', '      - ghost_content:/var/lib/ghost/content', '    depends_on:', '      db:', '        condition: service_healthy', '    healthcheck:', `      test: ["CMD", "node", "-e", "fetch('http://127.0.0.1:${GHOST_PORT}/blog/').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))"]`, '      interval: 5s', '      timeout: 5s', '      retries: 120', '      start_period: 30s',
    '  nginx:', `    image: ${NGINX_IMAGE}`, '    restart: unless-stopped', '    ports:', `      - "${PORT}:${PORT}"`, '    volumes:', `      - ${SERVICE_ROOT}/nginx.conf:/etc/nginx/conf.d/default.conf:ro`, '    depends_on:', '      ghost:', '        condition: service_healthy',
    'volumes:', '  mysql_data:', '  ghost_content:'
  ].join('\n')
  const nginx = ['server {', `    listen ${PORT};`, '    server_name _;', '    location = / { default_type text/plain; return 200 "' + MARKER + '\\n"; }', '    location /blog/ {', `        proxy_pass http://ghost:${GHOST_PORT};`, '        proxy_set_header Host $host;', '        proxy_set_header X-Real-IP $remote_addr;', '        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;', '        proxy_set_header X-Forwarded-Proto $scheme;', '    }', '}'].join('\n')
  return join([
    'set -eu', `image_cpu_profile=$(cat ${quote(`${state}/image-profile`)})`, `test "$image_cpu_profile" = "$(${profileProbe})"`, `install -d -o root -g root -m 0755 ${quote(SERVICE_ROOT)}`,
    "primary=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for (field=1; field<=NF; field++) if ($field == \"src\") { print $(field+1); exit }}' || true)", "[ -n \"$primary\" ] || primary=$(hostname -I 2>/dev/null | awk '{print $1}')", "case \"$primary\" in ''|*[!0-9a-fA-F:.]*) printf 'could not resolve a safe primary address\\n' >&2; exit 1;; esac",
    `password=$(sed -n 1p ${quote(`${CREDENTIALS}/database_password`)}); root_password=$(sed -n 1p ${quote(`${CREDENTIALS}/database_root_password`)})`,
    `umask 077; printf 'MYSQL_PASSWORD=%s\\nMYSQL_ROOT_PASSWORD=%s\\ndatabase__connection__password=%s\\nurl=http://%s:${PORT}/blog/\\nprivacy__useUpdateCheck=false\\n' "$password" "$root_password" "$password" "$primary" > ${quote(`${CREDENTIALS}/credentials.env`)}`, `chmod 0600 ${quote(`${CREDENTIALS}/credentials.env`)}`,
    `printf '%s\\n' ${compose.split('\n').map(quote).join(' ')} > ${quote(`${SERVICE_ROOT}/compose.yaml`)}`, `chmod 0644 ${quote(`${SERVICE_ROOT}/compose.yaml`)}`,
    `case "$image_cpu_profile" in standard) :;; compat) install -d -o root -g root -m 0755 ${quote(`${SERVICE_ROOT}/mysql-compat`)}; printf '%s\\n' ${ghostMysqlCompatibilityDockerfile().split('\n').map(quote).join(' ')} > ${quote(`${SERVICE_ROOT}/mysql-compat/Dockerfile`)}; sed -i ${quote(`s!${MYSQL_IMAGE}!${ghostMysqlCompatibilityImage(taskId)}!`)} ${quote(`${SERVICE_ROOT}/compose.yaml`)};; *) exit 1;; esac`,
    `printf '%s\\n' ${nginx.split('\n').map(quote).join(' ')} > ${quote(`${SERVICE_ROOT}/nginx.conf`)}`, `chmod 0644 ${quote(`${SERVICE_ROOT}/nginx.conf`)}`,
    `docker compose -p ${quote(PROJECT)} -f ${quote(`${SERVICE_ROOT}/compose.yaml`)} config --quiet`, 'printf \'%s\\n\' compose-ready'
  ])
}

function acquireComposeImages (state, taskId, profileProbe) {
  const compose = `docker compose --parallel 1 -p ${quote(PROJECT)} -f ${quote(`${SERVICE_ROOT}/compose.yaml`)}`
  const builder = `intentaiops-ghost-mysql-${taskId}`
  return join(['set -eu', `profile=$(cat ${quote(`${state}/image-profile`)})`, `test "$profile" = "$(${profileProbe})"`,
    `case "$profile" in standard) ${compose} pull --quiet;; compat) ! docker image inspect ${quote(ghostMysqlCompatibilityImage(taskId))} >/dev/null 2>&1; ! docker buildx inspect ${quote(builder)} >/dev/null 2>&1; docker buildx create --name ${quote(builder)} --driver docker-container --driver-opt image=${quote(GHOST_MYSQL_BUILDKIT)} --driver-opt network=host >/dev/null; : > ${quote(`${state}/builder-created`)}; cleanup_builder() { docker buildx rm --force ${quote(builder)} >/dev/null 2>&1 || true; }; trap cleanup_builder EXIT HUP INT TERM; docker buildx build --builder ${quote(builder)} --progress quiet --network host --load --tag ${quote(ghostMysqlCompatibilityImage(taskId))} ${quote(`${SERVICE_ROOT}/mysql-compat`)}; docker image inspect ${quote(ghostMysqlCompatibilityImage(taskId))} --format '{{.Id}}' > ${quote(`${state}/compat-image.after`)}; cleanup_builder; trap - EXIT HUP INT TERM; ${compose} pull --quiet ghost nginx;; *) exit 1;; esac`,
    "printf '%s\\n' images-ready"])
}

function startCompose () {
  const compose = `docker compose -p ${quote(PROJECT)} -f ${quote(`${SERVICE_ROOT}/compose.yaml`)}`
  return join(['set -eu', `${compose} up -d --pull never`, waitCompose('db'), waitCompose('ghost'), `frontend_ready=; for attempt in $(seq 1 60); do if curl --fail --silent --show-error --max-time 5 http://127.0.0.1:${PORT}/ | grep -Fx ${quote(MARKER)}; then frontend_ready=yes; break; fi; sleep 2; done; [ "$frontend_ready" = yes ]`])
}

function verifyCompose (state) {
  const compose = `docker compose -p ${quote(PROJECT)} -f ${quote(`${SERVICE_ROOT}/compose.yaml`)}`
  return join([
    'set -eu', waitCompose('db'), waitCompose('ghost'),
    `${compose} exec -T ghost node -p "require('/var/lib/ghost/current/package.json').version" | grep -Fx ${quote(COMPOSE_VERSION)}`,
    `profile=$(cat ${quote(`${state}/image-profile`)}); case "$profile" in standard) expected_mysql=8.4.11;; compat) expected_mysql=${GHOST_MYSQL_COMPAT_VERSION};; *) exit 1;; esac`,
    `${compose} exec -T db mysql --version | grep -F "Ver $expected_mysql"`,
    `${compose} exec -T db sh -c 'MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root --batch --skip-column-names ${DATABASE} -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE()"' | awk '$1 > 0 { ok=1 } END { exit !ok }'`,
    `${compose} exec -T ghost node -e "fetch('http://127.0.0.1:${GHOST_PORT}/blog/').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))"`,
    `curl --fail --silent --show-error --max-time 5 http://127.0.0.1:${PORT}/ | grep -Fx ${quote(MARKER)}`,
    `curl --fail --silent --show-error --max-time 10 http://127.0.0.1:${PORT}/blog/ >/dev/null`,
    'printf \'%s\\n\' ghost-verified'
  ])
}

function removeCompose (state, taskId) {
  const compose = `docker compose -p ${quote(PROJECT)} -f ${quote(`${SERVICE_ROOT}/compose.yaml`)}`
  const commands = ['set -eu', `[ -d ${quote(state)} ] || { printf '%s\n' already-reverted; exit 0; }`, `profile=$(cat ${quote(`${state}/image-profile`)}); case "$profile" in standard|compat) :;; *) exit 1;; esac`, `if command -v docker >/dev/null 2>&1; then if [ -e ${quote(`${state}/builder-created`)} ]; then docker buildx rm --force ${quote(`intentaiops-ghost-mysql-${taskId}`)} >/dev/null 2>&1 || true; ! docker buildx inspect ${quote(`intentaiops-ghost-mysql-${taskId}`)} >/dev/null 2>&1; fi; if [ -f ${quote(`${SERVICE_ROOT}/compose.yaml`)} ]; then ${compose} down --volumes --remove-orphans; fi; fi`]
  composeImages(taskId).forEach((image, index) => commands.push(`if command -v docker >/dev/null 2>&1 && [ ! -e ${quote(`${state}/image-${index}.existed`)} ]${index === 1 ? ' && [ "$profile" = standard ]' : index >= 3 ? ` && [ "$profile" = compat ] && [ -e ${quote(`${state}/builder-created`)} ]` : ''}; then ${index === 3 ? `if docker image inspect ${quote(image)} >/dev/null 2>&1; then test -s ${quote(`${state}/compat-image.after`)}; test "$(docker image inspect ${quote(image)} --format '{{.Id}}')" = "$(cat ${quote(`${state}/compat-image.after`)})"; fi; ` : ''}docker image rm ${quote(image)} >/dev/null 2>&1 || true; fi`))
  return join(commands)
}

function restoreDocker (state) {
  return join([
    'set -eu', `[ -d ${quote(state)} ] || { printf '%s\n' already-reverted; exit 0; }`, `if [ ! -e ${quote(`${state}/docker.existed`)} ]; then`, removeDebianPackages(`${state}/packages.added`),
    'rm -f /etc/apt/sources.list.d/docker.sources /etc/apt/keyrings/docker.asc', 'rm -rf -- /var/lib/docker /var/lib/containerd', 'fi',
    `if [ -e ${quote(`${state}/docker.active`)} ]; then systemctl start docker 2>/dev/null || true; else systemctl stop docker 2>/dev/null || true; fi`, `rm -rf -- ${quote(state)}`
  ])
}

function addedDebianPackages (state) {
  return `awk 'FILENAME == ARGV[1] { if ($1 == "ii") present[$2] = 1; next } $1 == "ii" && !($2 in present) { print $2, $3 }' ${quote(`${state}/packages.before`)} ${quote(`${state}/packages.after`)} > ${quote(`${state}/packages.added`)}`
}

function removeDebianPackages (list) {
  return `if [ -s ${quote(list)} ]; then packages=$(awk '{print $1}' ${quote(list)} | tr '\\n' ' '); [ -z "$packages" ] || DEBIAN_FRONTEND=noninteractive apt-get purge -y $packages; fi`
}

function waitUrl (url, attempts) {
  return `ready=; for attempt in $(seq 1 ${attempts}); do if curl --fail --silent --show-error --max-time 3 ${quote(url)} >/dev/null 2>&1; then ready=yes; break; fi; sleep 5; done; [ "$ready" = yes ]`
}

function waitCompose (service) {
  return `ready=; for attempt in $(seq 1 180); do status=$(docker inspect ${quote(`${PROJECT}-${service}-1`)} --format '{{if .State.Health}}{{.State.Health.Status}}{{end}}' 2>/dev/null || true); [ "$status" = healthy ] && ready=yes && break; sleep 5; done; [ "$ready" = yes ]`
}

function item (id, phase, command, purpose, dependsOn = [], timeoutMs = 300000, executionMode, risk = 'change') {
  return { id, phase, command, purpose, risk, timeoutMs, requiresSudo: true, dependsOn, ...(executionMode ? { executionMode } : {}) }
}

function join (parts) {
  return parts.filter(Boolean).join('; ').replaceAll('then; ', 'then ').replaceAll('else; ', 'else ')
}

function quote (value) {
  return `'${String(value).replaceAll("'", '\'\\\'\'')}'`
}
