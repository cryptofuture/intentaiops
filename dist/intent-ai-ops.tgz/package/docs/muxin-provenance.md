# Workspace provenance

The browser workspace adapts Muxin by Lumary Labs LLC, pinned at
`5a86e1d43ca49c434bd47f4a75d5b0aed0a19b0b`:
<https://github.com/LumaryLabsLLC/muxin/tree/5a86e1d43ca49c434bd47f4a75d5b0aed0a19b0b>.
Muxin is Rust/GPUI, not an imported web frontend. Adapted code remains Apache-2.0;
see the bundled license and retained attribution below. This is a provenance
record, not a requirement to follow that product's design in future changes.

## Retained attribution

Intent AI Ops, Copyright 2026 Intent AI Ops <admin@intentaiops.top>.
Adapted workspace visual structure and theme/color derivation: Muxin,
Copyright 2026 Lumary Labs LLC, Apache License 2.0.

Upstream NOTICE:

> This product includes third-party components under their own licenses;
> see THIRD_PARTY_NOTICES.md in the upstream distribution.

Only the relevant fonts and adapted visual/theme material are included here.
Bundled font, Preact, ghostty-web and Lucide license texts are distributed under
`src/operator-web/licenses/`. The optional node-pty dependency retains its license
in its installed package. Required attribution is retained here instead of a
root NOTICE file, as permitted by Apache-2.0 section 4(d).

- `src/ui/root.rs`: sidebar/tree, navigation, favorites; default 256 px, range 220-420 px.
- `overview.rs`, `detail.rs`, `kit.rs`: compact cards, 14 px gaps, 300 px overview cards,
  resource/status panels and semantic roles.
- `activity.rs`, `run.rs`, `panes.rs`: adjacent event details, explicit host results,
  independently closeable/resizable managed-task views, not remote terminals.
- `theme.rs`, `themes.rs`, `palette.rs`, `settings.rs`: System/Light/Dark resolution,
  independent palette choices, searchable previews and cancel/confirm behavior.
- `terminal/colors.rs`: 16 ANSI colors, semantic overrides and HSL bright shifts;
  supported SGR styling is rendered as text spans, not terminal commands.

`web/themes/palettes.js` contains all 27 canonical IDs and base palettes, without
renaming or approximation. `test/fixtures/muxin-themes.rs` retains the pinned
upstream reference independently of the registry. Tests compare actual values.
Graphite/Dusk and Paper/Dawn remain distinct. Frappé and Rosé names are preserved.
Defaults are System, light Dawn and dark Dusk. Dusk/Dawn retain secondary orange
accents and primary gradients. Both macOS palettes request platform fonts;
no Apple fonts are redistributed.

The compiled browser runtime also bundles Preact (MIT); its full license is
included alongside the font and Muxin licenses in the installed assets.

Derived opacity states and the weighted-RGB 0.55 accent-foreground threshold
follow upstream, including canvas compositing with 40% black. This is not WCAG
relative luminance. Essential approval buttons additionally use separately named
`approval_text` and `approval_surface` roles (the palette's text and surface),
with the original accent gradient as a border. Destructive actions retain text
and a warning icon. No universal AA claim is made for original palettes.

Geist 400 and Geist Mono 400 come from upstream `assets/fonts`, with their full
SIL Open Font License 1.1 in the installed assets. Icons are Unicode/system-font
glyphs; no upstream icon collections or proprietary system fonts are bundled.
No Muxin networking, daemon, remote desktop, cloud, runner, clipboard or QUIC
implementation is included.

Intent-specific changes: existing signed execution/recovery controllers, durable
approval projections, local-only HTTP authentication, profile preferences,
cross-process host scheduling, and demand-driven Netdata metrics. Browser views
never run shell commands directly.

## Bundled themes

| ID | Display name | Kind |
| --- | --- | --- |
| graphite | Muxin Graphite | Dark |
| dusk | Muxin Dusk | Dark |
| macos-dark | macOS Dark | Dark |
| gruvbox-dark | Gruvbox Dark | Dark |
| catppuccin-mocha | Catppuccin Mocha | Dark |
| catppuccin-macchiato | Catppuccin Macchiato | Dark |
| catppuccin-frappe | Catppuccin Frappé | Dark |
| tokyo-night | Tokyo Night | Dark |
| nord | Nord | Dark |
| rose-pine | Rosé Pine | Dark |
| solarized-dark | Solarized Dark | Dark |
| dracula | Dracula | Dark |
| everforest-dark | Everforest Dark | Dark |
| kanagawa-wave | Kanagawa Wave | Dark |
| github-dark | GitHub Dark | Dark |
| paper | Muxin Paper | Light |
| dawn | Muxin Dawn | Light |
| macos-light | macOS Light | Light |
| gruvbox-light | Gruvbox Light | Light |
| catppuccin-latte | Catppuccin Latte | Light |
| tokyo-night-day | Tokyo Night Day | Light |
| nord-light | Nord Light | Light |
| rose-pine-dawn | Rosé Pine Dawn | Light |
| solarized-light | Solarized Light | Light |
| everforest-light | Everforest Light | Light |
| kanagawa-lotus | Kanagawa Lotus | Light |
| github-light | GitHub Light | Light |
